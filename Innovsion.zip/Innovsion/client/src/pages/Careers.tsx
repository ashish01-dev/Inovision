import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Route, Building, Briefcase, GraduationCap, TrendingUp, Users } from "lucide-react";

interface CareerPath {
  degree: string;
  duration: string;
  paths: {
    government: string[];
    private: string[];
    higher_studies: string[];
    entrepreneurship: string[];
  };
}

const careerData: CareerPath[] = [
  {
    degree: "B.Tech/B.E. (Engineering)",
    duration: "4 years",
    paths: {
      government: ["ISRO Scientist", "Railway Engineer", "PWD Engineer", "Defense Services"],
      private: ["Software Engineer", "Product Manager", "Tech Consultant", "Project Manager"],
      higher_studies: ["M.Tech", "MBA", "MS Abroad", "Ph.D Research"],
      entrepreneurship: ["Tech Startup", "Engineering Consultancy", "Product Development", "EdTech"]
    }
  },
  {
    degree: "MBBS (Medicine)",
    duration: "5.5 years",
    paths: {
      government: ["Government Doctor", "Medical Officer", "Health Inspector", "Public Health"],
      private: ["Private Practice", "Hospital Doctor", "Medical Consultant", "Healthcare Tech"],
      higher_studies: ["MD/MS", "DM/MCh", "MPH", "Medical Research"],
      entrepreneurship: ["Healthcare Startup", "Medical Devices", "Telemedicine", "Health Tech"]
    }
  },
  {
    degree: "B.Com/BBA (Commerce)",
    duration: "3 years",
    paths: {
      government: ["Banking (SBI PO)", "Civil Services (IAS/IPS)", "Income Tax Officer", "Auditor"],
      private: ["Chartered Accountant", "Investment Banking", "Finance Manager", "Business Analyst"],
      higher_studies: ["MBA", "CA", "CFA", "Masters in Finance"],
      entrepreneurship: ["Business Startup", "Financial Services", "E-commerce", "Consulting"]
    }
  },
  {
    degree: "B.A. (Arts/Humanities)",
    duration: "3 years",
    paths: {
      government: ["Civil Services", "Teaching", "Social Worker", "Cultural Officer"],
      private: ["Journalism", "Content Writing", "HR Manager", "Marketing"],
      higher_studies: ["M.A.", "B.Ed", "Law (LLB)", "Social Work"],
      entrepreneurship: ["Media House", "Content Agency", "NGO", "Cultural Events"]
    }
  }
];

const pathIcons = {
  government: Building,
  private: Briefcase,
  higher_studies: GraduationCap,
  entrepreneurship: TrendingUp
};

const pathColors = {
  government: "bg-blue-100 text-blue-800",
  private: "bg-green-100 text-green-800", 
  higher_studies: "bg-purple-100 text-purple-800",
  entrepreneurship: "bg-orange-100 text-orange-800"
};

export default function Careers() {
  const [selectedDegree, setSelectedDegree] = useState(careerData[0]);
  const [selectedPath, setSelectedPath] = useState<keyof typeof pathIcons | null>(null);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-cyan-50 pt-20">
      <div className="container mx-auto px-6 py-12">
        <div className="text-center mb-16">
          <div className="w-16 h-16 bg-gradient-to-br from-accent to-cyan-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Route className="text-white text-2xl" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Course-to-Career Path Mapping</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Visualize your journey from education to career success with interactive pathways
          </p>
        </div>

        {/* Degree Selection */}
        <Card className="mb-8 shadow-lg">
          <CardHeader>
            <CardTitle className="text-center">Choose Your Degree Stream</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
              {careerData.map((career) => (
                <Button
                  key={career.degree}
                  variant={selectedDegree.degree === career.degree ? "default" : "outline"}
                  className="h-auto p-4 text-left flex flex-col items-start"
                  onClick={() => setSelectedDegree(career)}
                  data-testid={`button-degree-${career.degree.toLowerCase().replace(/\s+/g, '-')}`}
                >
                  <div className="font-semibold text-sm mb-1">{career.degree}</div>
                  <div className="text-xs opacity-70">{career.duration}</div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Career Path Visualization */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Left Side - Degree Info */}
          <div className="lg:col-span-1">
            <Card className="sticky top-8">
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <GraduationCap className="h-5 w-5" />
                  <span>{selectedDegree.degree}</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="text-sm font-medium text-muted-foreground">Duration</div>
                    <div className="text-lg font-semibold">{selectedDegree.duration}</div>
                  </div>
                  
                  <div>
                    <div className="text-sm font-medium text-muted-foreground mb-2">Career Paths Available</div>
                    <div className="space-y-2">
                      {Object.entries(pathIcons).map(([key, Icon]) => (
                        <div 
                          key={key}
                          className={`flex items-center space-x-2 p-2 rounded-lg cursor-pointer transition-colors ${
                            selectedPath === key ? 'bg-primary text-primary-foreground' : 'hover:bg-muted'
                          }`}
                          onClick={() => setSelectedPath(selectedPath === key ? null : key as keyof typeof pathIcons)}
                        >
                          <Icon className="h-4 w-4" />
                          <span className="text-sm capitalize">{key.replace('_', ' ')}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Right Side - Career Paths */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="government" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="government" className="text-xs">Government</TabsTrigger>
                <TabsTrigger value="private" className="text-xs">Private</TabsTrigger>
                <TabsTrigger value="higher_studies" className="text-xs">Higher Studies</TabsTrigger>
                <TabsTrigger value="entrepreneurship" className="text-xs">Startup</TabsTrigger>
              </TabsList>

              {Object.entries(selectedDegree.paths).map(([pathType, careers]) => {
                const Icon = pathIcons[pathType as keyof typeof pathIcons];
                return (
                  <TabsContent key={pathType} value={pathType} className="space-y-4">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Icon className="h-5 w-5" />
                          <span className="capitalize">{pathType.replace('_', ' ')} Sector</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid md:grid-cols-2 gap-4">
                          {careers.map((career, index) => (
                            <Card key={index} className="border hover:shadow-md transition-shadow">
                              <CardContent className="p-4">
                                <div className="flex items-center justify-between mb-2">
                                  <h4 className="font-semibold">{career}</h4>
                                  <Badge 
                                    variant="secondary" 
                                    className={pathColors[pathType as keyof typeof pathColors]}
                                  >
                                    {pathType.replace('_', ' ')}
                                  </Badge>
                                </div>
                                <p className="text-sm text-muted-foreground">
                                  {pathType === 'government' && "Stable career with good benefits and social impact"}
                                  {pathType === 'private' && "Dynamic environment with growth opportunities"}
                                  {pathType === 'higher_studies' && "Advanced specialization and research opportunities"}
                                  {pathType === 'entrepreneurship' && "Create your own path and build something new"}
                                </p>
                                <div className="mt-3 flex items-center justify-between">
                                  <div className="flex items-center space-x-1 text-xs text-muted-foreground">
                                    <Users className="h-3 w-3" />
                                    <span>High demand</span>
                                  </div>
                                  <Button size="sm" variant="ghost" className="text-xs">
                                    Learn More →
                                  </Button>
                                </div>
                              </CardContent>
                            </Card>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </TabsContent>
                );
              })}
            </Tabs>
          </div>
        </div>

        {/* Interactive Flow Chart */}
        <Card className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50">
          <CardHeader>
            <CardTitle className="text-center">Your Career Journey</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row items-center justify-between space-y-8 md:space-y-0 md:space-x-8 p-6">
              {/* Step 1 */}
              <div className="text-center flex-1">
                <div className="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <GraduationCap className="text-white text-xl" />
                </div>
                <h3 className="font-semibold mb-2">{selectedDegree.degree}</h3>
                <p className="text-sm text-muted-foreground">{selectedDegree.duration} of focused study</p>
              </div>

              {/* Arrow */}
              <div className="hidden md:block">
                <div className="w-8 h-0.5 bg-gradient-to-r from-blue-500 to-purple-500"></div>
              </div>

              {/* Step 2 */}
              <div className="text-center flex-1">
                <div className="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Route className="text-white text-xl" />
                </div>
                <h3 className="font-semibold mb-2">Choose Your Path</h3>
                <p className="text-sm text-muted-foreground">Multiple career options available</p>
              </div>

              {/* Arrow */}
              <div className="hidden md:block">
                <div className="w-8 h-0.5 bg-gradient-to-r from-purple-500 to-green-500"></div>
              </div>

              {/* Step 3 */}
              <div className="text-center flex-1">
                <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
                  <TrendingUp className="text-white text-xl" />
                </div>
                <h3 className="font-semibold mb-2">Build Your Career</h3>
                <p className="text-sm text-muted-foreground">Continuous growth and success</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <div className="text-center mt-12">
          <Button size="lg" className="px-8 py-3" data-testid="button-explore-colleges">
            Find Colleges for Your Chosen Stream
          </Button>
        </div>
      </div>
    </div>
  );
}
