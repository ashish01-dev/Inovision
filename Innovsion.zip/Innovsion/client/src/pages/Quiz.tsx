import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Brain, ChevronRight, RotateCcw, Download, Save } from "lucide-react";
import { useLocation } from "wouter";

interface Question {
  id: number;
  question: string;
  options: string[];
  category: "academic" | "personality" | "interests" | "environment";
}

interface QuizResult {
  stream: string;
  score: number;
  description: string;
  courses: string[];
  careers: string[];
}

const questions: Question[] = [
  {
    id: 1,
    question: "Which of these activities do you find most engaging?",
    options: [
      "Solving mathematical problems",
      "Creating artistic designs", 
      "Leading team projects",
      "Analyzing data patterns"
    ],
    category: "interests"
  },
  {
    id: 2,
    question: "What type of learning environment do you prefer?",
    options: [
      "Quiet library or study room",
      "Interactive group discussions",
      "Hands-on laboratory work",
      "Outdoor field experiences"
    ],
    category: "environment"
  },
  {
    id: 3,
    question: "Which subject area interests you most?",
    options: [
      "Physics and Mathematics",
      "Biology and Chemistry",
      "History and Literature",
      "Business and Economics"
    ],
    category: "academic"
  },
  {
    id: 4,
    question: "How do you prefer to work on projects?",
    options: [
      "Independently with minimal supervision",
      "In small collaborative teams",
      "With clear instructions and structure",
      "Leading and organizing others"
    ],
    category: "personality"
  },
  {
    id: 5,
    question: "What motivates you most in your studies?",
    options: [
      "Understanding complex concepts",
      "Helping others and making a difference",
      "Creating something new and innovative",
      "Achieving recognition and success"
    ],
    category: "interests"
  },
  {
    id: 6,
    question: "Which activity would you choose for a weekend?",
    options: [
      "Reading about scientific discoveries",
      "Visiting art museums or cultural events",
      "Playing sports or outdoor activities",
      "Learning new technical skills online"
    ],
    category: "interests"
  }
];

export default function Quiz() {
  const [, setLocation] = useLocation();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const [showResults, setShowResults] = useState(false);
  const [results, setResults] = useState<QuizResult[]>([]);

  const isQuizComplete = Object.keys(answers).length === questions.length;
  const progress = (Object.keys(answers).length / questions.length) * 100;

  const handleAnswerChange = (value: string) => {
    setAnswers(prev => ({
      ...prev,
      [questions[currentQuestion].id]: value
    }));
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const calculateResults = () => {
    // Simple scoring algorithm based on answers
    const scores = {
      science: 0,
      commerce: 0,
      arts: 0,
      engineering: 0
    };

    Object.values(answers).forEach((answer, index) => {
      // Basic scoring logic - in real app, this would be more sophisticated
      if (answer.includes("mathematical") || answer.includes("Physics") || answer.includes("data")) {
        scores.science += 2;
        scores.engineering += 1;
      }
      if (answer.includes("Business") || answer.includes("Economics") || answer.includes("recognition")) {
        scores.commerce += 2;
      }
      if (answer.includes("artistic") || answer.includes("History") || answer.includes("cultural")) {
        scores.arts += 2;
      }
      if (answer.includes("laboratory") || answer.includes("technical") || answer.includes("complex")) {
        scores.engineering += 2;
      }
    });

    const resultData: QuizResult[] = [
      {
        stream: "Science (PCM/PCB)",
        score: scores.science,
        description: "Perfect for students interested in research, medicine, or technical fields.",
        courses: ["B.Sc Physics", "B.Tech Engineering", "MBBS", "B.Sc Chemistry"],
        careers: ["Doctor", "Engineer", "Researcher", "Data Scientist"]
      },
      {
        stream: "Commerce",
        score: scores.commerce,
        description: "Ideal for business-minded students with leadership qualities.",
        courses: ["B.Com", "BBA", "CA", "Economics Honors"],
        careers: ["Chartered Accountant", "Business Manager", "Entrepreneur", "Finance Analyst"]
      },
      {
        stream: "Arts/Humanities",
        score: scores.arts,
        description: "Great for creative and socially conscious individuals.",
        courses: ["BA English", "Psychology", "Sociology", "Political Science"],
        careers: ["Journalist", "Psychologist", "Civil Services", "Teacher"]
      },
      {
        stream: "Engineering/Technology",
        score: scores.engineering,
        description: "Perfect for problem-solvers who love innovation and technology.",
        courses: ["B.Tech CSE", "B.Tech Mechanical", "B.Tech Electronics", "B.Arch"],
        careers: ["Software Engineer", "Mechanical Engineer", "Architect", "Tech Entrepreneur"]
      }
    ].sort((a, b) => b.score - a.score);

    setResults(resultData);
    setShowResults(true);
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setShowResults(false);
    setResults([]);
  };

  if (showResults) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pt-20">
        <div className="container mx-auto px-6 py-12">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h1 className="text-4xl font-bold mb-4">Your Personalized Results</h1>
              <p className="text-xl text-muted-foreground">Based on your responses, here are your recommended streams and career paths</p>
            </div>

            <div className="space-y-6">
              {results.map((result, index) => (
                <Card key={result.stream} className={`transition-all duration-300 ${index === 0 ? 'ring-2 ring-primary shadow-xl' : ''}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-2xl">{result.stream}</CardTitle>
                      <div className="flex items-center space-x-2">
                        {index === 0 && <Badge className="bg-primary">Best Match</Badge>}
                        <Badge variant="outline">{result.score} points</Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground mb-6">{result.description}</p>
                    
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-semibold mb-3">Recommended Courses:</h4>
                        <div className="flex flex-wrap gap-2">
                          {result.courses.map(course => (
                            <Badge key={course} variant="secondary">{course}</Badge>
                          ))}
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-semibold mb-3">Career Opportunities:</h4>
                        <div className="flex flex-wrap gap-2">
                          {result.careers.map(career => (
                            <Badge key={career} variant="outline">{career}</Badge>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row gap-4 mt-12 justify-center">
              <Button 
                onClick={() => setLocation("/careers")}
                className="px-8 py-3"
                data-testid="button-explore-careers"
              >
                Explore Career Paths
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
              
              <Button 
                onClick={() => setLocation("/colleges")}
                variant="outline"
                className="px-8 py-3"
                data-testid="button-find-colleges"
              >
                Find Colleges
                <ChevronRight className="ml-2 h-4 w-4" />
              </Button>
              
              <Button 
                onClick={resetQuiz}
                variant="ghost"
                className="px-8 py-3"
                data-testid="button-retake-quiz"
              >
                <RotateCcw className="mr-2 h-4 w-4" />
                Retake Quiz
              </Button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 pt-20">
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Brain className="text-white text-2xl" />
            </div>
            <h1 className="text-4xl font-bold mb-4">Aptitude & Interest Assessment</h1>
            <p className="text-xl text-muted-foreground">Discover your strengths and find the perfect educational path</p>
          </div>

          <Card className="shadow-2xl">
            <CardHeader>
              <div className="flex items-center justify-between mb-4">
                <CardTitle>Question {currentQuestion + 1} of {questions.length}</CardTitle>
                <Badge variant="outline">{Math.round(progress)}% Complete</Badge>
              </div>
              <Progress value={progress} className="w-full" />
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-xl font-semibold mb-6">{questions[currentQuestion].question}</h3>
                
                <RadioGroup 
                  value={answers[questions[currentQuestion].id] || ""} 
                  onValueChange={handleAnswerChange}
                  className="space-y-3"
                >
                  {questions[currentQuestion].options.map((option, index) => (
                    <div key={index} className="flex items-center space-x-3 p-4 border rounded-xl hover:bg-muted/50 transition-colors">
                      <RadioGroupItem value={option} id={`option-${index}`} />
                      <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer text-base">
                        {option}
                      </Label>
                    </div>
                  ))}
                </RadioGroup>
              </div>

              <div className="flex justify-between pt-6 border-t">
                <Button 
                  onClick={prevQuestion}
                  disabled={currentQuestion === 0}
                  variant="outline"
                  data-testid="button-previous-question"
                >
                  Previous
                </Button>
                
                <div className="space-x-4">
                  {currentQuestion === questions.length - 1 ? (
                    <Button 
                      onClick={calculateResults}
                      disabled={!answers[questions[currentQuestion].id]}
                      className="px-8"
                      data-testid="button-get-results"
                    >
                      Get Results
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  ) : (
                    <Button 
                      onClick={nextQuestion}
                      disabled={!answers[questions[currentQuestion].id]}
                      data-testid="button-next-question"
                    >
                      Next
                      <ChevronRight className="ml-2 h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quiz Tips */}
          <Card className="mt-8 bg-blue-50 border-blue-200">
            <CardContent className="p-6">
              <h4 className="font-semibold mb-2">💡 Tips for best results:</h4>
              <ul className="text-sm text-muted-foreground space-y-1">
                <li>• Answer honestly based on your genuine interests</li>
                <li>• Don't overthink - go with your first instinct</li>
                <li>• Consider what activities make you lose track of time</li>
                <li>• Think about subjects where you naturally excel</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
